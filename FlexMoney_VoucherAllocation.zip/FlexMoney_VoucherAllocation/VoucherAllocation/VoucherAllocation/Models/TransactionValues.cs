﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VoucherAllocation
{
    class TransactionValues
    {
        internal DateTime ExpirtyDate;
        internal int txnId;
        internal decimal amount;

        public static TransactionValues FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(',');
            TransactionValues transactionValues = new TransactionValues();
            transactionValues.ExpirtyDate = Convert.ToDateTime(values[2]);
            transactionValues.txnId = Convert.ToInt32(values[0]);
            transactionValues.amount = Convert.ToDecimal(values[1]);
            return transactionValues;
        }
    }
}
