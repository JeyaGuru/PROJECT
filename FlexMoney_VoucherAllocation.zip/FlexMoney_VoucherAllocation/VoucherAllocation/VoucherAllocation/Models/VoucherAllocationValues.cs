﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VoucherAllocation
{
    class VoucherAllocationValues
    {
        internal int txnId;
        internal decimal txn_amount;
        internal decimal voucher_amount;
        internal string voucher_code;
    }
}
