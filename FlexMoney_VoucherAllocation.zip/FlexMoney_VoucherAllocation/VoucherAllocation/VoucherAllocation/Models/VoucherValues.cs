﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VoucherAllocation
{
    internal class VoucherValues
    {
        internal DateTime ExpirtyDate;
        internal decimal amount;
        internal string vouchercode;
        internal bool IsAssigned;

        public static VoucherValues FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(',');
            VoucherValues VoucherValues = new VoucherValues();
            VoucherValues.ExpirtyDate = Convert.ToDateTime(values[2]);
            VoucherValues.amount = Convert.ToInt32(values[1]);
            VoucherValues.vouchercode = values[0];
            VoucherValues.IsAssigned = false;
            return VoucherValues;
        }
    }
}
