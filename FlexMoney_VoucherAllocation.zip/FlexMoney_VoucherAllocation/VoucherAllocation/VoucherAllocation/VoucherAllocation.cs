﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace VoucherAllocation
{
    class VoucherAllocation : VoucherAllocationBase
    {
        static void Main(string[] args)
        {
            ProcessAllocation();
            Console.ReadKey();
        }
    }
}
