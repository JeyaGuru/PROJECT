﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace VoucherAllocation
{
    class VoucherAllocation
    {
        static void Main(string[] args)
        {
            //Enter the default path where transaction & voucher file located
            Console.WriteLine("Enter the Valid Document Path example:D:\\"+"\\"+"FlexMoney_VoucherAllocation"+"\\"+"\\");
            var MainFilePath = Console.ReadLine();
            if (!Directory.Exists(MainFilePath))
            {
                Console.WriteLine("Please Enter the Valid Document Path  example: D:\\" + "\\" + "FlexMoney_VoucherAllocation" + "\\" + "\\");

                if(!Directory.Exists(MainFilePath+"transaction.csv"))
                Console.WriteLine("Path doesn't consists transaction.csv");

                if (!Directory.Exists(MainFilePath + "voucher.csv"))
                    Console.WriteLine("Path doesn't consists voucher.csv");
            }
            else
            {
                
                List<TransactionValues> transactionValues;
                List<VoucherValues> vouchervalues;
                List<OuputValues> outputs;

                //method to retrieve & process the csv files
                ProcessCsvFiles(MainFilePath, out transactionValues, out vouchervalues, out outputs);

                //method to assign vouchers to transactions
                AssignVouchersToTransactions(transactionValues, vouchervalues, outputs);

                //method to Convert the vouchers assigned values to csv in default path
                SaveToCsv(outputs, MainFilePath);
            }
            Console.ReadKey();

        }
        private static List<VoucherValues> ConvertVoucherFileToList(string MainFilePath)
        {
            try
            {
                var vouchers = File.ReadAllLines(MainFilePath + "Voucher.csv").Skip(1).Select(x => VoucherValues.FromCsv(x)).ToList().OrderByDescending(x => x.amount).ToList();
                Console.WriteLine("Processed Voucher.csv, successfully");
                return vouchers;
            }
            catch
            {
                Console.WriteLine("Unable to processed Voucher.csv, check the file format/ file path");
                return new List<VoucherValues>();
            }

        }

        private static List<TransactionValues> ConvertTransactionFileToList(string MainFilePath)
        {

            try
            {
                var transactions = File.ReadAllLines(MainFilePath + "transaction.csv").Skip(1).Select(x => TransactionValues.FromCsv(x)).ToList();
                Console.WriteLine("Processed transaction.csv, successfully");
                return transactions;
            }
            catch
            {
                Console.WriteLine("Unable to processed transaction.csv, check the file format/ file path");
                return new List<TransactionValues>();
            }
        }


        private static void ProcessCsvFiles(string MainFilePath, out List<TransactionValues> transactionValues, out List<VoucherValues> vouchervalues, out List<OuputValues> outputs)
        {
            transactionValues = ConvertTransactionFileToList(MainFilePath);
            vouchervalues = ConvertVoucherFileToList(MainFilePath);
            outputs = new List<OuputValues>();
        }

        private static void AssignVouchersToTransactions(List<TransactionValues> transactionValues, List<VoucherValues> vouchervalues, List<OuputValues> outputs)
        {
            foreach (var item in transactionValues)
            {
                decimal balanceAmount = item.amount;
                foreach (var item1 in vouchervalues.Where(x => !x.IsAssigned && x.ExpirtyDate >= item.ExpirtyDate))
                {
                    if (item1.amount <= balanceAmount)
                    {
                        OuputValues outputValue = new OuputValues();
                        outputValue.txnId = item.txnId;
                        outputValue.txn_amount = item.amount;
                        outputValue.voucher_amount = item1.amount;
                        outputValue.voucher_code = item1.vouchercode;
                        item1.IsAssigned = true;
                        balanceAmount -= item1.amount;
                        outputs.Add(outputValue);
                    }
                    if (balanceAmount == 0)
                    {
                        break;
                    }
                }
            }
        }


        internal static void SaveToCsv(List<OuputValues> output, string path)
        {
            try
            {
                StringBuilder csv = new StringBuilder();
                csv.Append("txnid" + ',');
                csv.Append("txnAmount" + ',');
                csv.Append("voucherAmount" + ',');
                csv.Append("voucherCode" + ',');
                csv.Append("\r\n");

                foreach (var item in output)
                {
                    csv.Append(Convert.ToString(item.txnId) + ',');
                    csv.Append(Convert.ToString(item.txn_amount) + ',');
                    csv.Append(Convert.ToString(item.voucher_amount) + ',');
                    csv.Append(item.voucher_code + ',');
                    csv.Append("\r\n");
                }

                File.WriteAllText(path + "voucher_allocation.csv", csv.ToString());

                Console.WriteLine("voucher_allocation.csv, file has been stored to "+ path);
            }
            catch
            {
                Console.WriteLine("voucher_allocation.csv, file has not stored to " + path);
            }
        }

    }

    internal class VoucherValues
    {
        internal DateTime ExpirtyDate;
        internal decimal amount;
        internal string vouchercode;
        internal bool IsAssigned;

        public static VoucherValues FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(',');
            VoucherValues VoucherValues = new VoucherValues();
            VoucherValues.ExpirtyDate = Convert.ToDateTime(values[2]);
            VoucherValues.amount = Convert.ToInt32(values[1]);
            VoucherValues.vouchercode = values[0];
            VoucherValues.IsAssigned = false;
            return VoucherValues;
        }
    }

    internal class TransactionValues
    {
        internal DateTime ExpirtyDate;
        internal int txnId;
        internal decimal amount;

        public static TransactionValues FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(',');
            TransactionValues transactionValues = new TransactionValues();
            transactionValues.ExpirtyDate = Convert.ToDateTime(values[2]);
            transactionValues.txnId = Convert.ToInt32(values[0]);
            transactionValues.amount = Convert.ToDecimal(values[1]);
            return transactionValues;
        }
    }

    internal class OuputValues
    {
        internal int txnId;
        internal decimal txn_amount;
        internal decimal voucher_amount;
        internal string voucher_code;
    }
}
