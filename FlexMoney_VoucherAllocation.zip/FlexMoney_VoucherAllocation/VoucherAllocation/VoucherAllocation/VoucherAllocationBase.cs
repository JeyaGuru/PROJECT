﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace VoucherAllocation
{
    internal class VoucherAllocationBase
    {
        internal static void ProcessAllocation()
        {
            //Enter the default path where transaction & voucher file located
            Console.WriteLine("Enter the Valid Document Path example:D:\\" + "\\" + "FlexMoney_VoucherAllocation" + "\\" + "\\");
            var MainFilePath = Console.ReadLine().Trim();
            MainFilePath = MainFilePath.Contains(":") && MainFilePath.Length >= 2 && !MainFilePath.EndsWith("\\") ? MainFilePath + "\\" : MainFilePath;
            if (!Directory.Exists(MainFilePath))
                Console.WriteLine("Please Enter the Valid Document Path  example: D:\\" + "\\" + "FlexMoney_VoucherAllocation" + "\\" + "\\");
            else if (!File.Exists(MainFilePath + "transaction.csv"))
                Console.WriteLine("Path doesn't consists transaction.csv");
            else if (!File.Exists(MainFilePath + "voucher.csv"))
                Console.WriteLine("Path doesn't consists voucher.csv");
            else
            {
                List<TransactionValues> transactionValues;
                List<VoucherValues> vouchervalues;
                List<VoucherAllocationValues> outputs;

                //method to retrieve & process the csv files
                ProcessCsvFiles(MainFilePath, out transactionValues, out vouchervalues, out outputs);

                //method to assign vouchers to transactions
                if (transactionValues.Any() && vouchervalues.Any())
                    AssignVouchersToTransactions(transactionValues, vouchervalues, outputs);
                else
                    Console.WriteLine("voucher (or) transaction not exists");

                //method to Convert the vouchers assigned values to csv in default path
                if (outputs.Any())
                    SaveToCsv(outputs, MainFilePath);
                else if (transactionValues.Any() && vouchervalues.Any())
                    Console.WriteLine("No valid voucher\\transaction found for allocation");

            }
        }
        internal static void SaveToCsv(List<VoucherAllocationValues> output, string path)
        {
            try
            {
                StringBuilder csv = new StringBuilder();
                csv.Append("txnid" + ',');
                csv.Append("txnAmount" + ',');
                csv.Append("voucherAmount" + ',');
                csv.Append("voucherCode" + ',');
                csv.Append("\r\n");

                foreach (var item in output)
                {
                    csv.Append(Convert.ToString(item.txnId) + ',');
                    csv.Append(Convert.ToString(item.txn_amount) + ',');
                    csv.Append(Convert.ToString(item.voucher_amount) + ',');
                    csv.Append(item.voucher_code + ',');
                    csv.Append("\r\n");
                }

                File.WriteAllText(path + "voucher_allocation.csv", csv.ToString());

                Console.WriteLine("voucher_allocation.csv, file has been stored to " + path);
            }
            catch
            {
                Console.WriteLine("voucher_allocation.csv, file has not stored to " + path);
            }
        }

        private static void AssignVouchersToTransactions(List<TransactionValues> transactionValues, List<VoucherValues> vouchervalues, List<VoucherAllocationValues> outputs)
        {
            foreach (var item in transactionValues)
            {
                decimal balanceAmount = item.amount;
                List<VoucherAllocationValues> vouchers = new List<VoucherAllocationValues>();
                foreach (var item1 in vouchervalues.Where(x => !x.IsAssigned && x.ExpirtyDate >= item.ExpirtyDate))
                {
                    if (item1.amount <= balanceAmount)
                    {
                        VoucherAllocationValues outputValue = new VoucherAllocationValues();
                        outputValue.txnId = item.txnId;
                        outputValue.txn_amount = item.amount;
                        outputValue.voucher_amount = item1.amount;
                        outputValue.voucher_code = item1.vouchercode;
                        item1.IsAssigned = true;
                        balanceAmount -= item1.amount;
                        vouchers.Add(outputValue);
                    }
                    if (balanceAmount == 0)
                    {
                        outputs.AddRange(vouchers);
                        break;
                    }
                }
            }
        }

        private static List<TransactionValues> ConvertTransactionFileToList(string MainFilePath)
        {

            try
            {
                var transactions = File.ReadAllLines(MainFilePath + "transaction.csv").Skip(1).Select(x => TransactionValues.FromCsv(x)).ToList();
                Console.WriteLine($"Processed transaction.csv, successfully. number of records = {transactions.Count}");
                return transactions;
            }
            catch
            {
                Console.WriteLine("Unable to processed transaction.csv, check the file format/ file path");
                return new List<TransactionValues>();
            }
        }

        private static List<VoucherValues> ConvertVoucherFileToList(string MainFilePath)
        {
            try
            {
                var vouchers = File.ReadAllLines(MainFilePath + "Voucher.csv").Skip(1).Select(x => VoucherValues.FromCsv(x)).ToList().OrderByDescending(x => x.amount).ToList();
                Console.WriteLine($"Processed Voucher.csv, successfully. number of records = {vouchers.Count}");
                return vouchers;
            }
            catch
            {
                Console.WriteLine("Unable to processed Voucher.csv, check the file format/ file path");
                return new List<VoucherValues>();
            }

        }
       
        private static void ProcessCsvFiles(string MainFilePath, out List<TransactionValues> transactionValues, out List<VoucherValues> vouchervalues, out List<VoucherAllocationValues> outputs)
        {
            transactionValues = ConvertTransactionFileToList(MainFilePath);
            vouchervalues = ConvertVoucherFileToList(MainFilePath);
            outputs = new List<VoucherAllocationValues>();
        }
    }
}