﻿using ConsoleApp3.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp3
{
    class Start
    {
        static void Main(string[] args)
        {
            BookingSystem flightBookingSystem = new FlightBookingSystem();           
            
            flightBookingSystem.AddTransport(new Transport("120"));
            flightBookingSystem.AddTransport(new Transport("121"));
            flightBookingSystem.AddBookingDetail(new BookingDetail(1, flightBookingSystem.transports.Where(x => x.Number == "120").FirstOrDefault(), Operation.B,
                SeatType.EC, 12, true));
            flightBookingSystem.AddBookingDetail(new BookingDetail(2, flightBookingSystem.transports.Where(x => x.Number == "121").FirstOrDefault(), Operation.B,
                SeatType.EC, 12, true));
            flightBookingSystem.CancelBookingDetail(1);
            flightBookingSystem.ViewBookingDetails();
            flightBookingSystem.ViewSummaryDetails();
            Console.ReadKey();
        }
    }
}
