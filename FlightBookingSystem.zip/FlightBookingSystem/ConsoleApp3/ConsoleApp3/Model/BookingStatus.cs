﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3.Model
{
    public enum BookingStatus
    {
        Booked,Cancelled
    }
}
