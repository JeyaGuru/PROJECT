﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3.Model
{
    public class BookingDetail
    {
        public int BookingId { get; set; }
        public Transport Transport { get; set; }
        public Operation operation { get; set; } 
        public SeatType SeatType { get; set; }
        public int TotalSeats { get; set; }
        public bool MealsRequired { get; set; }
        public BookingStatus BookingStatus { get; set; }
        public decimal Total { get; set; }
        public decimal CancelledAmount { get; set; }
        public List<Seat> BookedSeats { get; set; }

        public BookingDetail(int BookingId, Transport transport, Operation operation, SeatType seatType, int totalSeats, bool mealsRequired)
        {
            this.BookingId = BookingId;
            this.Transport = transport;
            this.SeatType = SeatType;
            this.TotalSeats = totalSeats;
            this.MealsRequired = mealsRequired;
            this.BookedSeats = new List<Seat>();
            BookSeats(transport);
        }        

        private int BookSeats(Transport transport)
        {
            int count = 0;
            foreach (var item in transport.Seats.Where(x => x.status != BookingStatus.Booked && x.Type == SeatType))
            {
                if (count >= TotalSeats)
                    break;
                item.status = BookingStatus.Booked;
                item.MealsRequired = MealsRequired;
                if (SeatType == SeatType.EC)
                    Total += 1000;
                else
                    Total += 2000;

                if (item.MealsRequired)
                    Total += 100;

                count++;
                BookedSeats.Add(item);
            }

            return count;
        }
    }
}
