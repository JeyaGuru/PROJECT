﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3.Model
{
    public class Seat
    {
        public int Number { get; set; }
        public SeatType Type { get; set; }
        public BookingStatus status { get; set; }
        public bool MealsRequired { get; set; }

        public Seat(int Number,SeatType Type,BookingStatus status,bool MealsRequired)
        {
            this.Number = Number;
            this.Type = Type;
            this.status = status;
            this.MealsRequired = MealsRequired;
        }
    }
}
