﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3.Model
{
    public class BookingSummary
    {
        List<Seat> Seats = new List<Seat>();
        public void ViewSumamry(Transport transport,List<BookingDetail> bookingDetails)
        {
            Seats = transport.Seats;
            Console.WriteLine("Flight Number {0}\nBooked Seats {1}\nMealsRequiredSeats {2}\nTotal Cost {3}\nAvailable Seats {4}",transport.Number,
                BookedSeats(),
                MealsRequiredSeats(),
                TotalCostReceived(bookingDetails,transport.Number),
                AvailableSeats());
            Console.WriteLine();
        }

        private string AvailableSeats()
        {
            return string.Join(" ,", Seats.Where(x => x.status != BookingStatus.Booked).Select(x => x.Number));
        }

        private static decimal TotalCostReceived(List<BookingDetail> bookingDetails,string Number)
        {
            return bookingDetails.Where(x=>x.Transport.Number==Number).Sum(x => x.Total);
        }

        private string MealsRequiredSeats()
        {
            return string.Join(" ,", Seats.Where(x => x.MealsRequired).Select(x => x.Number));
        }

        private string BookedSeats()
        {
            return string.Join(" ,", Seats.Where(x => x.status == BookingStatus.Booked).Select(x => x.Number));
        }
    }
}
