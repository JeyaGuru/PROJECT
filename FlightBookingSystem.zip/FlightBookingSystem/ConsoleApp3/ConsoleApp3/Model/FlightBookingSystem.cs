﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3.Model
{
    public class FlightBookingSystem : BookingSystem
    {
       BookingSummary bookingSummary;

       public FlightBookingSystem()
        {
            bookingSummary = new BookingSummary();
        }
        public override void ViewBookingDetails()
        {
            foreach (var item in bookingDetails)
            {
                Console.WriteLine("Booking Id {0}\nFlight Number {1}",item.BookingId,item.Transport.Number);
                if(item.BookingStatus==BookingStatus.Booked)
                {
                    if(item.SeatType==SeatType.EC)
                     Console.WriteLine("Economy Class {0}\nMeals Required {1}", string.Join(", ",item.BookedSeats.Select(x=>x.Number)), string.Join(", ", item.BookedSeats.Where(x=>x.MealsRequired).Select(x => x.Number)));
                    else
                        Console.WriteLine("Business Class {0}\nMeals Required {1}", string.Join(", ", item.BookedSeats.Select(x => x.Number)), string.Join(", ", item.BookedSeats.Where(x => x.MealsRequired).Select(x => x.Number)));
                    Console.WriteLine("Total Cost {0}", item.Total);
                }
                else
                {
                    Console.WriteLine("Cancelled");
                    Console.WriteLine("Total Cost {0}", item.CancelledAmount);
                }               
                Console.WriteLine();
            }
           
        }

        public override void ViewSummaryDetails()
        {
            foreach (var item in transports)
            {
                bookingSummary.ViewSumamry(item,bookingDetails.Where(x=>x.Transport.Number==item.Number).ToList());
            }
            Console.WriteLine();
        }
    }
}
