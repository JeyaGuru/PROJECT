﻿using ConsoleApp3.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    public abstract class BookingSystem
    {
        public List<Transport> transports;
        public List<BookingDetail> bookingDetails;
        public CancelBooking CancelBooking;
        public BookingSystem()
        {
            transports = new List<Transport>();
            bookingDetails = new List<BookingDetail>();
            CancelBooking = new CancelBooking();
        }
        public void AddTransport(Transport transport)
        {
            transports.Add(transport);
        }

        public void AddBookingDetail(BookingDetail bookingDetail)
        {
            bookingDetails.Add(bookingDetail);
        }
        public void CancelBookingDetail(int BookingId)
        {
            CancelBooking.CancelBookingById(BookingId,bookingDetails);
        }
        public abstract void ViewBookingDetails();
        public abstract void ViewSummaryDetails();
    }
}
