﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3.Model
{
    public class Transport
    {
        public string Number { get; set; }
        public List<Seat> Seats { get; set; }

        public Transport(string number)
        {
            Number = number;
            Seats = new List<Seat>();
            AddSeats();
        }

        public void AddSeats()
        {
            for (int i = 1; i <= 18; i++)
            {
                SeatType seatType = SeatType.BC;
                if (i > 6)
                {
                    seatType = SeatType.EC;
                }

                Seats.Add(new Seat(i, seatType, BookingStatus.Cancelled, false));
            }
        }
    }
}
