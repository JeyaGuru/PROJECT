﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3.Model
{
    public class CancelBooking
    {
       public void CancelBookingById(int BookingId,List<BookingDetail> bookingDetails)
        {
            var bookings = bookingDetails.Where(x => x.BookingId == BookingId).FirstOrDefault();
            bookings.BookingStatus = BookingStatus.Cancelled;
            bookings.CancelledAmount = bookings.TotalSeats * 400;
           foreach(var item in bookings.Transport.Seats)
            {
                item.MealsRequired = false;
                item.status = BookingStatus.Cancelled;        
            }
            bookings.Total = 0;
        }
    }
}
