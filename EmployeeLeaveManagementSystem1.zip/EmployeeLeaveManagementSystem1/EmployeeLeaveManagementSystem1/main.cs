﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagementSystem1
{
    class main
    {
        static void Main(string[] args)
        {
            Dictionary<string, EmployeeDetails> EmpDataBase = new Dictionary<string, EmployeeDetails>();
            //Dictionary<string, CompanyDetails> CompanyDetailsDataBase = new Dictionary<string, CompanyDetails>();
            //Dictionary<string, ClientDetails> ClientDetailsDataBase = new Dictionary<string, ClientDetails>();
            //
            String filepath = @"D:\Sample.txt";
            List<string> filein = File.ReadAllLines(filepath).ToList();
            while (true)
            {
                Console.WriteLine("******WELCOME*******");
                Console.WriteLine("please Enter Option\n1.Add Employee Details\n2.Display Employee Details\n3.Add company Details\n4.Display Company Details\n5.Add Client Details\n6.Display Client Details\n7.To exit");
                int option=Convert.ToInt32(Console.ReadLine());
                switch(option)
                {
                    case 1:
                        EmployeeDetails EmpObject = new EmployeeDetails();
                        EmpObject.AcceptEmployeeDetails();
                        EmpDataBase.Add(EmpObject.FirstName,EmpObject);
                        filein.Add(EmpObject.DisplayEmployeeDetails());
                        File.WriteAllLines(filepath,filein);
                        continue;
                    case 2:
                        Console.WriteLine("Please Enter the EmployeeID");
                        string EmpID = Console.ReadLine();
                        string ff= File.ReadAllText(filepath).ToString();
                        string[] Arr= ff.Split('*');
                        int c = 0;

                        for (int i = 0; i < Arr.Length; i++)
                        {
                            if (Arr[i].Contains(EmpID))
                            { Console.WriteLine(Arr[i]); c = 1; }
                        }
                        if (c==0)
                            Console.WriteLine("Please Enter the Valid EmployeeID");
                        continue;
                    //case 3:
                    //    CompanyDetails CompObject = new CompanyDetails();
                    //    CompObject.AddCompanyDetails();
                    //    CompanyDetailsDataBase.Add(CompObject.NameOfCompany,CompObject);
                    //    continue;
                    //case 4:
                    //    Console.WriteLine("Please Enter the CompanyName");
                    //    string CmpName = Console.ReadLine();
                    //    if (CompanyDetailsDataBase.ContainsKey(CmpName))
                    //    {
                    //        Console.WriteLine(CompanyDetailsDataBase[CmpName].DisplayCompanyDetails());
                    //    }
                    //    else
                    //        Console.WriteLine("Please Check The Company Name");
                    //    continue;
                    //case 5:
                    //    ClientDetails ClientObject = new ClientDetails();
                    //    ClientDetailsDataBase.Add(ClientObject.ClientName,ClientObject);
                    //    continue;
                    //case 6:
                    //    Console.WriteLine("Please Enter the ClientName");
                    //    string ClientName = Console.ReadLine();
                    //    if (ClientDetailsDataBase.ContainsKey(ClientName))
                    //    {
                    //        Console.WriteLine(ClientDetailsDataBase[ClientName].DisplayClientDetails());
                    //    }
                    //    else
                    //        Console.WriteLine("Please Check The Client Name");
                    //    continue;
                    case 3:
                        Console.WriteLine("*********ThankYou***********");
                        break;

                }if (option == 3) break;

            }
        }
    }
}
