﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{
    public class colour
    {
        public void ChangeBackGroundColour()
        {
            Console.WriteLine("Please Enter\n1.Blue-BackGround\n2.Green-BackGround\n3.Red-BackGround\n4.Yellow-BackGround\n5.White-BackGround");
             int option=Convert.ToInt32(Console.ReadLine());
            
            switch (option)
            {
               
                case 1:
                    Console.BackgroundColor = ConsoleColor.Blue;
                    break;
                case 2:
                    Console.BackgroundColor = ConsoleColor.Green;
                    break;
                case 3:
                    Console.BackgroundColor = ConsoleColor.Red;
                    break;
                case 4:
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    break;
                case 5:
                    Console.BackgroundColor = ConsoleColor.White;
                    break;
            }
            Console.Clear();
        }
        public void ChangeFontColour()
        {
            Console.WriteLine("Please Enter\n1.BlueFont\n2.Green\n3.Red\n4.Yellow\n5.White");
            int option;
            option = Convert.ToInt32(Console.ReadLine());
            switch (option)
            {
                case 1:
                    Console.ForegroundColor = ConsoleColor.Blue;
                    break;
                case 2:
                    Console.ForegroundColor = ConsoleColor.Green;
                    break;
                case 3:
                    Console.ForegroundColor = ConsoleColor.Red;
                    break;
                case 4:
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    break;
                case 5:
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
            }
        }
    }
}
