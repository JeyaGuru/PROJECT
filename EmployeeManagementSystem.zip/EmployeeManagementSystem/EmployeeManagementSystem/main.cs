﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EmployeeManagementSystem
{
    class main
    {

        static void Main(string[] args)
        {
            //HashMap<int,LinkedList<>> EmpDataBase = new Hash<List<string>>();
            Dictionary<string, EmployeeDetails> dc = new Dictionary<string, EmployeeDetails>();
            while (true)
            {
                Console.WriteLine("******Welcome********");
                Console.WriteLine("Enter 1.Add New Employee Details\n2.View Employee Details\n3.Change Screen Settings\n4.Exit");
                int choice;
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {

                    case 1:
                        EmployeeDetails ob = new EmployeeDetails();
                        ob.EmpDetails();
                        dc.Add(ob.EmployeeID, ob);
                        continue;
                    case 2:
                        Console.WriteLine("Please Enter the EmployeeID");
                        string EmployeeID = Console.ReadLine();
                        if (dc.ContainsKey(EmployeeID))
                        {
                            Console.WriteLine(dc[EmployeeID].EmployeeDisplay());
                        }
                        else
                        {
                            Console.WriteLine("Please Enter the Valid EmployeeID");
                        }
                        continue;
                    case 3:
                        while (true)
                        {
                            Console.WriteLine("Enter option\n1.ToChangeBackGroundColor\n2.ToChangeFontColor\n3.ToExitColourMenu");
                            int option = Convert.ToInt32(Console.ReadLine());
                            colour ColourObject = new colour();
                            switch (option)
                            {
                                case 1:
                                    ColourObject.ChangeBackGroundColour();
                                    break;
                                case 2:
                                    ColourObject.ChangeFontColour();
                                    break;
                                case 3:
                                    break;
                                default:
                                    Console.WriteLine("Please Enter valid option");
                                    break;
                            }
                            if (option == 3)
                                break;
                        }
                        continue;
                    case 4:
                        Console.WriteLine("**********ThankYou********");
                        setTimer objectTimer = new setTimer();
                        objectTimer.Totimer();
                        break;
                }
            }
        }
    }
}
