﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace EmployeeManagementSystem
{
     class setTimer
    {
        public void stop(object state)
        {
            Environment.Exit(0);
        }
        public  void Totimer()
        {
            Timer t = new Timer(stop, null, 2000,2000);
        }
    }
}
