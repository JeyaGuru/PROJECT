﻿namespace System.Web
{
    internal class Security
    {
    }
}