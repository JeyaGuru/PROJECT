﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EmployeeLeaveManagementSystem
{
    class EmployeeDetails
    {
       
        private string _firstName;
        private string _lastName;
        private string _addressLine1;
        private string _addressLine2;
        private string _dateOfBirth;
        private int _age;
        private double _ctc;
        private string _mobileNumber;
        private string _dateOfJoining;
        private string _location;
        private DateTime DOJ;
        //public string EmployeeID
        //{
        //    get { return _empId; }
        //    set 
        //    {
        //        _empId = value;
        //        while (true)
        //        {
        //            if (_empId.Length > 5)
        //            {                       
        //                break;
        //            }
        //            else
        //            {
        //                Console.WriteLine("Please Enter the employee ID more than 5 characters");
        //                _empId = Console.ReadLine();
        //            }
        //        }
        //    }
        //}
       
        private string _email;

        private string _employeeID;

        public string EmployeeID
        {
            get { return _employeeID; }
            set { _employeeID = value; }
        }

        public string Email 
        {
            get { return _email; }
            set { 
                _email = value; }
        }
        private string _password;

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }

        public string FirstName
        { 
            get
            {
                return _firstName;    
            }
            set
            {
                while (true)
                {
                    _firstName = value;
                    if (_firstName.Length <= 30)
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Please Enter the FirstName less then 30 characters");
                        _firstName = Console.ReadLine();
                    }
                }
            }

        }
        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
                while (true)
                {
                    if (_lastName.Length <= 30)
                    {
                        
                        break;
                    }
                    else
                    {
                        Console.WriteLine("please Enter the LastName less then 30 characters");
                        _lastName = Console.ReadLine();
                    }
                }
            }

        }
        public string AddressLine1
        {
            get
            {
                return _addressLine1;
            }
            set
            {
                _addressLine1 = value;
                while (true)
                {

                    if (_addressLine1.Length >= 20)
                    {
                       
                        break;
                    }
                    else
                    {
                        Console.WriteLine("please Enter the AddressLine1 to be greater then 30 characters");
                        _addressLine1=Console.ReadLine();
                    }
                }
            }

        }
        public string AddressLine2
        {
            get
            {
                return _addressLine2;
            }
            set
            {
                _addressLine2 = value;
                while (true)
                {
                    if (_addressLine2.Length >= 20)
                    {
                       
                        break;
                    }
                    else
                    {
                        Console.WriteLine("please Enter the Address greater then 20 characters");
                        _addressLine2 = Console.ReadLine();
                    }
                }
            }

        }
        public string DateOfBirth
        {

            get
            {
                return _dateOfBirth;
            }
            set
            {
                _dateOfBirth = value;
                string[] DateOfBirthArr = new string[3];
                DateOfBirthArr = _dateOfBirth.Split('/');
                while (true)
                {
                   
                    if (Convert.ToInt32(DateOfBirthArr[0]) >= 1 && Convert.ToInt32(DateOfBirthArr[0]) <= 12 && Convert.ToInt32(DateOfBirthArr[1]) >= 1 && Convert.ToInt32(DateOfBirthArr[1]) <= 31)
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("please Enter the valid DateOfBirth");
                        _dateOfBirth = Console.ReadLine();
                        DateOfBirthArr = _dateOfBirth.Split('/');
                    }
                }
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
                while (true)
                {
                    
                    if (_age >= 20 && _age <= 60)
                    {
                        
                        break;
                    }
                    else
                    {
                        Console.WriteLine("please Enter the valid Age");
                        _age=Convert.ToInt32(Console.ReadLine());

                    }
                }
            }
        }
        public double CTC
        {
            get
            {
                return _ctc;
            }
            set
            {
                _ctc = value;
                while (true)
                {
                    if (_ctc <= 100000)
                    {
                       
                        break;
                    }
                    else
                    {
                        Console.WriteLine("please Enter the salary  less then 1Lakhs");
                        _ctc = Convert.ToDouble(Console.ReadLine());
                    }
                }
            }
        }
        public string MobileNumber
        {
            get
            {
                return _mobileNumber;
            }
            set
            {
                _mobileNumber = value;
                while (true)
                {

                    if (_mobileNumber.Length==14 && _mobileNumber[0] == '+' && (_mobileNumber[1]-'0' >= 0 && _mobileNumber[1]-'0' <= 9) && (_mobileNumber[2]-'0' >= 0 && _mobileNumber[2]-'0' <= 9) && _mobileNumber[3] == ' ') 
                    {
                        
                        break;
                    }
                    else
                    {
                        Console.WriteLine("please Enter the valid CountryCode and MobileNumber");
                        _mobileNumber = Console.ReadLine();
                    }
                }
            }
        }
        public string DateOfJoining
        {

            get
            {
                return _dateOfJoining;
            }
            set
            {
                _dateOfJoining = value;
                string[] DateOfJoiningArr = new string[3];
                DateOfJoiningArr = _dateOfJoining.Split('/');
                while (true)
                {
                    
                    if (Convert.ToInt32(DateOfJoiningArr[0]) >= 1 && Convert.ToInt32(DateOfJoiningArr[0]) <= 12 && Convert.ToInt32(DateOfJoiningArr[1]) >= 1 && Convert.ToInt32(DateOfJoiningArr[1]) <= 31)
                    { 
                        break;
                    }
                    else
                    {
                        Console.WriteLine("please Enter the valid DateOfJoining");
                        _dateOfJoining = Console.ReadLine();
                        
                        DateOfJoiningArr = _dateOfJoining.Split('/');
                    }
                }
            }

        }
        public string Location
        {

            get
            {
                return _location;
            }
            set
            {
                _location = value;
            }

        }
        Random RandomNumber = new Random();
        public void EmpIdGenerator()
        {
            int EmpID = RandomNumber.Next(100, 999);
            EmployeeID += "E" + EmpID;
        }
        public void EmailAddressGenerator()
        {
            Email = FirstName + "." + LastName.Substring(0, 1) + "@odessatech.com";
        }
        public void PasswordGenerator()
        {
            Password = Guid.NewGuid().ToString("d").Substring(0, 8);
        }
        public void AcceptEmployeeDetails()
        {
            EmpIdGenerator();
            Console.WriteLine("Please Enter The FirstName");
            FirstName = Console.ReadLine();
            Console.WriteLine("Please Enter The LastName");
            LastName = Console.ReadLine();
            EmailAddressGenerator();
            PasswordGenerator();
            Console.WriteLine("Please Enter The AddressLine1");
            AddressLine1 = Console.ReadLine();
            Console.WriteLine("Please Enter The AddressLine2");
            AddressLine2 = Console.ReadLine();
            Console.WriteLine("Please Enter The DateOfBirth <mm/dd/yyyy>");
            DateOfBirth = Console.ReadLine();
            string[] Year = new string[3];
            Year = DateOfBirth.Split('/');
            Age = DateTime.Now.Year - (Convert.ToInt32(Year[2]));
            Console.WriteLine("Please Enter The CTC");
            CTC = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Please Enter The MobileNumber");
            MobileNumber = Console.ReadLine();
            Console.WriteLine("Please Enter The DateOfJoining <mm/dd/yyyy>");
            DateOfJoining = Console.ReadLine();
            string[] Date = new string[3];
            Date = DateOfJoining.Split('/');
            string DateDemo = Date[1] + "/" + Date[0] + "/" + Date[2];
            DOJ = DateTime.Parse(DateDemo);
            Console.WriteLine("Please Enter the Location");
            Location = Console.ReadLine();
        }
        public string DisplayEmployeeDetails()
        {
            return (EmployeeID + " :" + FirstName + " " + LastName + "\n"+Email+"\n" + AddressLine1 + "," + AddressLine2 + "\n" + Age + "Years\nSalary INR:" + CTC + "\n" + MobileNumber + "\nJoinedOn: " + DateOfJoining + "," +DOJ.DayOfWeek.ToString()+"\nLocation: "+Location);
        }
    }
}
