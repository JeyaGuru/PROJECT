﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagementSystem
{
    class ClientDetails
    {
        private string _clientName;

        public string ClientName
        {
            get { return _clientName; }
            set { _clientName = value; }
        }
        private string _clientAddress;

        public string ClientAddress
        {
            get { return _clientAddress; }
            set { _clientAddress = value; }
        }
        private string _clientContactNumber;

        public string ClientContactNumber
        {
            get { return _clientContactNumber; }
            set { _clientContactNumber = value; }
        }
        private string _countryRegion;

        public string CountryRegion
        {
            get { return _countryRegion; }
            set { _countryRegion = value; }
        }

        private string _countryCode;

        public string CountryCode
        {
            get { return _countryCode; }
            set { _countryCode = value;
                _countryCode = "+1";
            }
        }

        public ClientDetails()
        {
            Console.WriteLine("Please Enter the ClientName");
            ClientName = Console.ReadLine();
            Console.WriteLine("Please Enter ClientAddress");
            ClientAddress = Console.ReadLine();
            Console.WriteLine("Please Enter the ClientContactNumber");
            ClientContactNumber = Console.ReadLine();
            Console.WriteLine("Please Enter the CountryRegion");
            CountryRegion = Console.ReadLine();
        }
         public string DisplayClientDetails()
        {
            return (ClientName + "\n" + ClientAddress + "\n" + ClientContactNumber + "\n" +CountryCode+" "+ClientContactNumber+"\n"+CountryRegion+","+"US");
        }




    }
}
