﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagementSystem
{
    public class CompanyDetails
    {
        private string _nameOfCompany;

        public string NameOfCompany
        {
            get { return _nameOfCompany; }
            set { _nameOfCompany = value; }
        }

        private string _addressOfCompany;

        public string AddressOfCompany
        {
            get { return _addressOfCompany; }
            set { _addressOfCompany = value; }
        }
        private string _nameOfProject;

        public string NameOfProject
        {
            get { return _nameOfProject; }
            set { _nameOfProject = value; }
        }
        private string _nameOfProjectManager;

        public  string NameOfProjectManger
        {
            get { return _nameOfProjectManager; }
            set { _nameOfProjectManager = value; }
        }
        private string _managerContactNumber;

        public string ManagerContactNumber
        {
            get { return _managerContactNumber; }
            set { _managerContactNumber = value; }
        }

        private string _companyContactNumber;

        public string CompanyContactNumber
        {
            get { return _companyContactNumber; }
            set { _companyContactNumber = value; }
        }



        public void AddCompanyDetails()
        {
            Console.WriteLine("Please Enter the Company Name");
            NameOfCompany = Console.ReadLine();
            Console.WriteLine("Please Enter the Address of Company");
            AddressOfCompany = Console.ReadLine();
            Console.WriteLine("Please Enter the Project Name");
            NameOfProject = Console.ReadLine();
            Console.WriteLine("Please Enter the Project Manager Name");
            NameOfProjectManger = Console.ReadLine();
            Console.WriteLine("Please Enter the Manager Contact Number");
            ManagerContactNumber = Console.ReadLine();
            Console.WriteLine("Please Enter the Company Contact Number");
            CompanyContactNumber = Console.ReadLine();
           
        }
        public string DisplayCompanyDetails()
        {
            return (NameOfCompany + "\n" +AddressOfCompany+"\n"+NameOfProject+"\n"+NameOfProjectManger+"\nManagerContactNumber:"+ManagerContactNumber+"\nCompanyContactNumber :"+CompanyContactNumber);
        }
    }
}
